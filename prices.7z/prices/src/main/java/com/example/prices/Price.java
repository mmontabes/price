package com.example.prices;

import java.util.Date;

public class Price {


    private Long id;

    private Long brandId;
    private Date startDate;
    private Date endDate;
    private Integer priceList;
    private Long productId;
    private Integer priority;
    private Double price;
    private String currency;
}
